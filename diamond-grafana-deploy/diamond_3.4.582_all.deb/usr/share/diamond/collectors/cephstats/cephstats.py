# coding=utf-8

"""
Get ceph status from one node
"""

import subprocess
import re
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), 'ceph'))
from ceph import CephCollector

def doShellCommand(cmd):
    process = subprocess.Popen('set -o pipefail; ' + cmd, executable='/bin/bash', shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    process.wait()
    if process.returncode != 0:
        return process.returncode, process.stderr.read()
    else:
        return 0, process.stdout.read()

unitList = ('B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB')
def unitCompare(unit1, unit2):
    index1 = index2 = 0
    for i in range(1, len(unitList)):
        if unitList[i] == unit1:
            index1 = i
        if unitList[i] == unit2:
            index2 = i

    if index1 < index2:
        return -1
    elif index1 > index2:
        return 1
    else:
        return 0

def splitValueAndUnit(size):
    matchObj = re.match(r' *(\d+) *([KMGTPE]*B)', size)
    if matchObj:
        value = int(matchObj.group(1))
        unit = matchObj.group(2)
    else:
        value = 0
        unit = 'B'

    return value, unit

def unitTransfer(size, toUnit):
    fromIndex = toIndex = 0;

    value, fromUnit = splitValueAndUnit(size)
    for i in range(1, len(unitList)):
        if toUnit == unitList[i]:
            toIndex = i
        if fromUnit == unitList[i]:
            fromIndex = i

    if fromIndex > toIndex:
        value <<= 10 * (fromIndex - toIndex)
    elif fromIndex < toIndex:
        value >>= 10 * (toIndex - fromIndex)

    return str(value) + toUnit

def addCapacity(op1, op2):
    value1, unit1 = splitValueAndUnit(op1)
    value2, unit2 = splitValueAndUnit(op2)

    if (unitCompare(unit1, unit2) < 0):
        op2 = unitTransfer(op2, unit1)
        value2, unit2 = splitValueAndUnit(op2)
    else:
        op1 = unitTransfer(op1, unit2)
        value1, unit1 = splitValueAndUnit(op1)

    return str(value1+value2) + unit1

def sataAllocateSize():
    cmd = 'source /opt/osdeploy/admin_openrc.sh;'
    cmd = cmd + "cinder list --all | sed '1,3d;$d' | awk -F'|' 'BEGIN{size=0}{if($7~/sata/){size+=$6}}END{printf \"%dGB\", size}'"
    ret, size = doShellCommand(cmd)
    return size

def ssdAllocateSize():
    cmd = 'source /opt/osdeploy/admin_openrc.sh;'
    cmd = cmd + "cinder list --all | sed '1,3d;$d' | awk -F'|' 'BEGIN{size=0}{if($7~/ssd/){size+=$6}}END{printf \"%dGB\", size}'"
    ret, size = doShellCommand(cmd)
    return size

def imageAllocateSize():
    cmd = 'source /opt/osdeploy/admin_openrc.sh;'
    cmd = cmd + "glance image-list --all | sed '1,3d;$d' | awk -F'|' 'BEGIN{size=0}{size+=$6}END{printf \"%dGB\", size/1024/1024/1024}'"
    ret, size = doShellCommand(cmd)
    return size

def defaultAllocateSize(poolName):
    totalSize = '0MB'

    cmd = 'rbd ls ' + poolName
    ret, imageList = doShellCommand(cmd)
    if ret != 0:
        return totalSize

    for image in imageList.split():
        cmd = 'rbd info ' + poolName + '/' + image + ' | grep size | awk \'{printf $2" "$3}\''
        ret, imageSize = doShellCommand(cmd)
        if ret != 0:
            continue

        totalSize = addCapacity(totalSize, imageSize)

    return totalSize

allocateSizeDispatcher = {
    'volumes_2' : sataAllocateSize,
    'volumes'   : sataAllocateSize,
    'volumes_hp': ssdAllocateSize,
    'images'    : imageAllocateSize,
}

def calculateAllocateSize(poolName):
    if poolName in allocateSizeDispatcher:
        return allocateSizeDispatcher[poolName]()
    else:
        return defaultAllocateSize(poolName)

class CephStatsCollector(CephCollector):
    def transfer_value(self, value, valueType):
        if valueType in ('osdUsage'):
            value = float(value) * 100

        return value

    def publish_cmd_res(self, cmd, valueType):
        ret, res = doShellCommand(cmd)
        if ret != 0:
            self.log.info('run command `%s` failed(%d)' % (cmd, ret))
            self.log.info('%s' % res)
            res = '\n'

        stats = {}
        for line in res.split('\n'):
            if line == "": continue
            name, value = line.split(' ')
            stats[name] = self.transfer_value(value, valueType)

        self._publish_stats(valueType, stats)

    def poolUsage(self):
        cmd = 'ceph df | awk \'BEGIN{isPoolItem=0}{if(isPoolItem == 1) {print $1" "$3" "$5} else if ($1 == "NAME") isPoolItem=1}\''
        ret, poolList = doShellCommand(cmd)
        if ret != 0:
            self.log.info('run command `%s` failed(%d)' % (cmd, ret))
            self.log.info('%s' % poolList)
            poolList = '\n'

        stats = {}
        for line in poolList.split('\n'):
            if line == "": continue
            item = line.split()

            size = splitValueAndUnit(unitTransfer(item[1] + 'B', 'MB'))[0]
            name, value = '{0}.used {1}'.format(item[0], size).split(' ')
            stats[name] = value

            allocateSize = calculateAllocateSize(item[0])
            size = splitValueAndUnit(unitTransfer(allocateSize, 'MB'))[0]
            name, value = '{0}.allocated {1}'.format(item[0], size).split(' ')
            stats[name] = value

            size = splitValueAndUnit(unitTransfer(item[2] + 'B', 'MB'))[0]
            name, value = '{0}.total {1}'.format(item[0], size).split(' ')
            stats[name] = value

        self._publish_stats('poolUsage', stats)

    def osdUsage(self):
        cmd = 'ceph osd df | sort -n -k 1 | awk \'{if($1 != "ID" && $1 != "TOTAL" && $1 != "MIN/MAX") print $1" "$7}\''
        self.publish_cmd_res(cmd, 'osdUsage')

    def osdPerf(self):
        cmd = 'ceph osd perf | awk \'{if($1 != "osd"){print "fs_commit."$1" "$2; print "fs_apply."$1" "$3}}\''
        self.publish_cmd_res(cmd, 'osdLatency')

    def collect(self):
        """
        Collect ceph stats
        """
        self.poolUsage()
        self.osdUsage()
        self.osdPerf()
